package com.projectse.aads.student_agenda.Interfaces;

import com.projectse.aads.student_agenda.Models.TaskModel;

/**
 * Created by Davlatbek Isroilov on 4/4/2016.
 * Innopolis University
 */
public interface TaskOverviewCaller {
    void callTaskOverview(TaskModel taskModel);
}
