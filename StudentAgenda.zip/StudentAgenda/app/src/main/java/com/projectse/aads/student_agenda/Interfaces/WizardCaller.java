package com.projectse.aads.student_agenda.Interfaces;

/**
 * Created by smith on 4/19/16.
 */
public interface WizardCaller {
    public void callWizard();
}
