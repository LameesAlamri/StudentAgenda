package com.projectse.aads.student_agenda.Interfaces;

/**
 * Created by smith on 4/19/16.
 */
public interface WizardManager {
    public void closeWizard();
    public void callIntroFragment();
    public void callWeekFragment();
    public void callTasksFragment();
    public void callAllocateFragment();
    public void callManualAllocateFragment();
    public void callPreviewFragment();
}
