package com.projectse.aads.student_agenda.Interfaces;

/**
 * Created by smith on 3/29/16.
 */
public interface ParentFragment {
    public void onChildCreated();
}
