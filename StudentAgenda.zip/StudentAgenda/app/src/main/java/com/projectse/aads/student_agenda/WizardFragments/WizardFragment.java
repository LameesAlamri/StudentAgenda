package com.projectse.aads.student_agenda.WizardFragments;

import android.app.Activity;
// import android.app.Fragment;
import androidx.fragment.app.Fragment;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;

import com.projectse.aads.student_agenda.DrawableHelper;
import com.projectse.aads.student_agenda.Interfaces.WizardManager;
import com.projectse.aads.student_agenda.R;
import com.projectse.aads.student_agenda.WizardActivity;

import java.io.IOException;


public abstract class WizardFragment extends Fragment{

    protected WizardActivity wizardActivity;
    protected WizardManager wizardManager;

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if(activity instanceof WizardActivity){
            wizardActivity = (WizardActivity) activity;
        }
        if(activity instanceof WizardManager){
            wizardManager = (WizardManager) activity;
        }
    }

    public void setDrawablesToImageViews(View view){
        if(view == null)
            view = getView();
        try{

            ImageView koala = (ImageView) view.findViewById(R.id.koala);
            if(koala != null)
                koala.setImageDrawable(DrawableHelper.getAssetImage(getActivity(),"koala"));

            ImageView cloud = (ImageView) view.findViewById(R.id.cloud);
            if(cloud != null)
                cloud.setImageDrawable(DrawableHelper.getAssetImage(getActivity(),"cloud"));
        } catch (IOException e) {
//            e.printStackTrace();
            Log.d("MyImageError",e.getLocalizedMessage());
            Log.d("MyImageError",e.toString());
        }
    }

}
