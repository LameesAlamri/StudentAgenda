package com.projectse.aads.student_agenda.NotifyService;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;

import java.util.List;


public abstract class TaskScheduler extends JobScheduler {
    @Override
    public int schedule(JobInfo job) {
        return 0;
    }

    @Override
    public void cancel(int jobId) {

    }

    @Override
    public void cancelAll() {

    }

    @Override
    public List<JobInfo> getAllPendingJobs() {
        return null;
    }
}
