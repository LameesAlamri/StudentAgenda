package com.projectse.aads.student_agenda.Fragments;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.location.Criteria;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.ScrollView;
import android.widget.Toast;

import com.projectse.aads.student_agenda.DBService.DatabaseHelper;
import com.projectse.aads.student_agenda.Interfaces.ActualTasksCaller;
import com.projectse.aads.student_agenda.LocationService;
import com.projectse.aads.student_agenda.Models.CourseModel;
import com.projectse.aads.student_agenda.Models.TaskModel;
import com.projectse.aads.student_agenda.NotifyService.AlertReceiver;
import com.projectse.aads.student_agenda.R;
import com.vansuita.pickimage.bean.PickResult;
import com.vansuita.pickimage.bundle.PickSetup;
import com.vansuita.pickimage.dialog.PickImageDialog;
import com.vansuita.pickimage.listeners.IPickResult;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.Locale;
import java.util.Objects;
import java.util.TimeZone;

import static android.app.Activity.RESULT_OK;
import static android.content.Context.MODE_PRIVATE;
import static androidx.core.app.ActivityCompat.recreate;


public class AddTaskFragment extends TaskFragment implements LocationListener {
    ActualTasksCaller actualTasksCaller;
    private Long parent_id = -1L;
    private Menu menu;
    long course_id, default_start_time;

    private LocationManager location = null;
    public static Location CURRENT_LOCATION = null;
    private static final int MY_PERMISSION_FOR_ACCESS_LOCATION = 1;

    // Shared preference to save image file path as temporary
    SharedPreferences imagePathSharedPreferences;

    //Uri to store the image uri
    Uri filePath;

    //Bitmap to get image from gallery
    Bitmap bitmap;

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(Objects.requireNonNull(activity.getCurrentFocus()).getWindowToken(), 0);
    }

    @Override
    public void onDestroyOptionsMenu() {
        super.onDestroyOptionsMenu();
    }

    @Override
    public void onDestroy() {
//        hideSoftKeyboard(getActivity());
        if(location != null){
            location.removeUpdates((LocationListener) this);
            location = null;
        }
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        getActivity().setTitle("Add Task");
        // todo
        imagePathSharedPreferences = getActivity().getSharedPreferences("image_preferences", MODE_PRIVATE);
        View view = inflater.inflate(R.layout.shared_content_task_new, container, false);
        setupUI(view);
        getViews(view);
        task = new TaskModel();
        course = new CourseModel();
        setPrioritySpinner(view);
        setHasOptionsMenu(true);
        getPermissionToAccessLocation();
        initializeLocation();
        return view;
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
        if (activity instanceof ActualTasksCaller) {
            actualTasksCaller = (ActualTasksCaller) activity;
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        getActivity().getMenuInflater().inflate(R.menu.menu_plan_addtask, menu);
        this.menu = menu;
        menu.findItem(R.id.action_addtask).setEnabled(true);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        if (getArguments() != null) {
            course_id = getArguments().getLong("course_id");
            default_start_time = getArguments().getLong("default_start_time");

            if(default_start_time > 0) {
                Calendar startDate = Calendar.getInstance();
                startDate.setTimeInMillis(default_start_time);
                setDateTime(startTimeDateView, startDate.getTimeInMillis());
            }
            if (course_id != -1L){
                try {
                    textViewCourseLabel.setText(db.getCourse(course_id).getAbbreviation());
                    textViewCourseLabel.setBackgroundColor(db.getCourse(course_id).getClr());
                    editTextCourseName.setText(db.getCourse(course_id).getName());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    @Override
    protected void getViews(View view) {
        super.getViews(view);
        textViewCourseLabel.setVisibility(View.INVISIBLE);
        switchDone.setVisibility(View.INVISIBLE);
        editTextCourseName.setFocusable(false);
        if (getActivity().getIntent().getBooleanExtra("hide_subtasks", false)) {
            ScrollView sub_l = (ScrollView) view.findViewById(R.id.subtasksScrollView);
            sub_l.setVisibility(View.INVISIBLE);
        }
        buttonCourseSelect.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                onClickCourseList(v);
            }
        });
        // TODO
        imageViewDailyNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showImageChooser();
            }
        });

        imageViewTaskLocation.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                getLocation();
            }
        });

    }

    private void initializeLocation() {
        location = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
        getActivity().getSystemService(Context.NOTIFICATION_SERVICE);
    }

    private void getLocation() {
        if (ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            getPermissionToAccessLocation();
        } else {
            //Initiate location tracking
            Criteria criteria = new Criteria();
            criteria.setAccuracy(Criteria.NO_REQUIREMENT);
            criteria.setPowerRequirement(Criteria.NO_REQUIREMENT);
            //Get location service
            location = (LocationManager) getActivity().getSystemService(Context.LOCATION_SERVICE);
            //Get best provider among the three, GPS, network and WIFI
            String best = location.getBestProvider(criteria, true);

            //Get location updated every minute and after 100 meters distance
            //location.requestLocationUpdates(best, 60000, 100,  this);
            //For more location accuracy, do not relay on the provider
            // returend by Android criteria, instead supply GPS proivder
            //explicitly
            location.requestLocationUpdates(LocationManager.GPS_PROVIDER, 60000, 30000, this);
            //This to anticipate if GPS is not available on the device or not enabled
            //In this case our location service will get the available location provder
            //Bear in mind that accuracy will vary based on the returned provider.
            Location lasKnownLocation = LocationService.getCurrentLocation(getActivity());
            if (lasKnownLocation != null) {
                onLocationChanged(lasKnownLocation);
            }
        }
    }


    @Override
    public void onLocationChanged(Location location) {
        //sendNotification("Service", "Location Changed");
        CURRENT_LOCATION = location;
        saveLocation(location);
    }

    private void saveLocation(Location location) {
        Double lat = location.getLatitude();
        Double lon = location.getLongitude();
        latText.setText(String.valueOf(lat));
        lonText.setText(String.valueOf(lon));
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {

    }

    @Override
    public void onProviderEnabled(String provider) {

    }

    @Override
    public void onProviderDisabled(String provider) {

    }


    @TargetApi(23)
    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Make sure it's our original READ_CONTACTS request
        if (requestCode == MY_PERMISSION_FOR_ACCESS_LOCATION) {
            if (grantResults.length == 1 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(getActivity(), "Read LOCATION permission denied", Toast.LENGTH_SHORT).show();
            } else {
                // showRationale = false if user clicks Never Ask Again, otherwise true
                boolean showRationale = shouldShowRequestPermissionRationale(Manifest.permission.ACCESS_COARSE_LOCATION);


                if (showRationale) {
                    // do something here to handle degraded mode
                } else {
                    Toast.makeText(getContext(), "Read LOCATION permission granted", Toast.LENGTH_SHORT).show();
                }
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
        recreate(getActivity());
    }


    @TargetApi(23)
    public void getPermissionToAccessLocation() {
        if (ContextCompat.checkSelfPermission(getActivity(), Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                ||
                ContextCompat.checkSelfPermission(getContext(), Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {

            shouldShowRequestPermissionRationale(
                    Manifest.permission.ACCESS_COARSE_LOCATION);
            shouldShowRequestPermissionRationale(
                    Manifest.permission.ACCESS_FINE_LOCATION);


            requestPermissions(
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                            Manifest.permission.ACCESS_COARSE_LOCATION
                    }, MY_PERMISSION_FOR_ACCESS_LOCATION
            );

        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

//        if (requestCode == IntentResolver.REQUESTER) {
            if (resultCode == RESULT_OK) {
                filePath = data.getData();
                Uri selectedImageUri = data.getData();
                File mFile = new File(data.getData().getPath());
                try {
                    Toast.makeText(getContext(), "Image set to bitmap", Toast.LENGTH_SHORT).show();
                    bitmap = MediaStore.Images.Media.getBitmap(getContext().getContentResolver(), filePath);
                    imageViewDailyNote.setImageBitmap(bitmap);
                    saveImage(selectedImageUri, bitmap, mFile);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            } else {
                Toast.makeText(getActivity(), "Error", Toast.LENGTH_LONG).show();
            }
      //  }
    }

    //method to show image chooser
    public void showImageChooser() {

        PickSetup setup = new PickSetup();

        setup.setTitle("Choose your image")
                .setCameraButtonText("Camera")
                .setGalleryButtonText("Gallery")
                .setCancelText("Cancel");
        // .setMaxSize(1000) TODO - limit the image size and any files with compressor size


        //opening file chooser
        PickImageDialog.build(setup, new IPickResult() {
            public void onPickResult(PickResult r) {
                //TODO: do what you have to...
                if (r != null && r.getError() == null) {

                    filePath = r.getUri();

                    //the image URI
                    Uri selectedImageUri = r.getUri();
                    File mFile = new File(r.getPath());

                    try {
                        Toast.makeText(getActivity(), "Image set to bitmap", Toast.LENGTH_SHORT).show();
                        bitmap = MediaStore.Images.Media.getBitmap(getActivity().getContentResolver(), filePath);
                        imageViewDailyNote.setImageBitmap(bitmap);
                        saveImage(selectedImageUri, bitmap, mFile);
                    } catch (IOException e) {
                        e.printStackTrace();
                    }

                } else {
                    Toast.makeText(getActivity(), r.getError().getMessage(), Toast.LENGTH_LONG).show();
                }
            }
        }).show(getActivity().getSupportFragmentManager());  //getSupportFragmentManager()

    }

    @SuppressLint("MissingPermission")
    public void saveImage(Uri fileUri, Bitmap bitmap, File mFile) {

        try {
            Toast.makeText(getContext(), "Image Saved", Toast.LENGTH_SHORT).show();
            File file = new File(getActivity().getFilesDir(), "daily_note" + "_" + System.currentTimeMillis() + ".jpg");
            FileOutputStream out = getActivity().openFileOutput(file.getName(), MODE_PRIVATE);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 70, out);
            out.close();

            SharedPreferences.Editor prefEditor = imagePathSharedPreferences.edit();
            prefEditor.putString("dailyNote image", file.getAbsolutePath());
            prefEditor.apply();

        } catch (IOException e) {
            e.printStackTrace();
        }

/*        if (mFile.exists()) {
            if (mFile.delete()) {
                Log.e("Old file deleted", "Old file deleted");
            } else {
                Log.e("file not Deleted :", String.valueOf(fileUri));
            }
        }*/
    }




    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            // Respond to the action bar's Up/Home button
            case android.R.id.home:
                return true;
        }
        if (item.getTitle().equals("addtask")) {
            addAndSaveToDb(getView());
            for (TaskModel taskModel : super.listAllSubtasks) {
                task.addSubtask(taskModel);
                db.updateTask(task);
            }
        }
        return super.onOptionsItemSelected(item);
    }

    /**
     * On-click button function for saving created task to database
     * and then going to actual tasks
     *
     * @param v
     */
    public void addAndSaveToDb(View v) {
        if (validateTaskFields(v)) {
            long task_id = addTaskToDatabase();
            if (course_id != 0) {
                db.addCourseToTask(task_id);
                db.updateCourseToTask(task_id, course_id);
                Log.d("course id", course_id + "");
            } else {
                course_id = dialogFragmentBuilder.getCourseId();
                if (course_id != 0) {
                    db.addCourseToTask(task_id);
                    db.updateCourseToTask(task_id, course_id);
                    Log.d("course id", course_id + "");
                }
            }

            if (task_id > 0) {
                // clear the temporary image file path variable in the sharedPreferences to use it again for new insert/update
                imagePathSharedPreferences.edit().remove("dailyNote image").apply();
                imagePathSharedPreferences.edit().clear().apply();
            }

            getFragmentManager().popBackStack();
//            hideSoftKeyboard(getActivity());
        }
    }

    /**
     * Creating task data and adding to local database
     *
     * @return True if all data is successfully recorded to database
     */
    public long addTaskToDatabase() {
        Calendar deadLineCal, startTimeCal;
        deadLineCal = getCalendarFromTxtEditViews(deadlineDateView);
        try {
            task.setPriority(task.intToPriority(spinnerPriority.getSelectedItemPosition()));
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (startTimeDateView.getText().toString().equals(""))
            startTimeCal = Calendar.getInstance(TimeZone.getTimeZone("UTC"), Locale.getDefault());
        else
            startTimeCal = getCalendarFromTxtEditViews(startTimeDateView);

        task.setName(nameView.getText().toString());
        task.setDescription(descView.getText().toString());
        task.setDeadline(deadLineCal);
        task.setStartTime(startTimeCal);
        task.setImageFilePath(imagePathSharedPreferences.getString("dailyNote image", ""));
        if (!latText.getText().toString().isEmpty() && lonText.getText().toString().isEmpty())
        task.setLatitude(Double.parseDouble(latText.getText().toString()));
        task.setLongitude(Double.parseDouble(lonText.getText().toString()));
        if (!durationView.getText().toString().equals("")/* || !durationView.getText().toString().equals("0")*/)
            task.setDuration(Long.parseLong(durationView.getText().toString()));
        else task.setDuration(1L);

        if (!(parent_id < 0))
            task.setParentTaskId(parent_id);
        setAlarmNotif();
        db = DatabaseHelper.getsInstance(getActivity());
        return db.addTask(task);
    }

    public void setAlarmNotif() {
        Long time = new GregorianCalendar().getTimeInMillis() + 5 * 1000;

        Log.d("TIME_NOTIFICATIONS SET", time.toString() + "");
        Intent alertIntent = new Intent(getActivity(), AlertReceiver.class);
        AlarmManager alarmManager = (AlarmManager)
                getActivity().getSystemService(Context.ALARM_SERVICE);
        alarmManager.set(AlarmManager.RTC_WAKEUP, time,
                PendingIntent.getBroadcast(getActivity(), 1, alertIntent, PendingIntent.FLAG_UPDATE_CURRENT));
    }

    public void setupUI(View view) {
        //Set up touch listener for non-text box views to hide keyboard.
        if (view != null) {
/*            if (!(view instanceof EditText)) {
                view.setOnTouchListener(new View.OnTouchListener() {
                    public boolean onTouch(View v, MotionEvent event) {
                        switch (event.getAction()) {
                            case MotionEvent.ACTION_DOWN:
                                hideSoftKeyboard(Objects.requireNonNull(getActivity()));
                                break;
                            case MotionEvent.ACTION_UP:
                                v.performClick();
                                break;
                            default:
                                break;
                        }
                        return true;
//                        hideSoftKeyboard(Objects.requireNonNull(getActivity()));
//                        return false;
                    }
                });
            }*/
            //If a layout container, iterate over children and seed recursion.
            if (view instanceof ViewGroup) {
                for (int i = 0; i < ((ViewGroup) view).getChildCount(); i++) {
                    View innerView = ((ViewGroup) view).getChildAt(i);
                    setupUI(innerView);
                }
            }
        }
    }

    @Override
    public void setPrioritySpinner(View view) {
        super.setPrioritySpinner(view);
        try {
            switch (spinnerPriority.getSelectedItemPosition()) {
                case 0:
                    priorityColor.setBackgroundColor(getResources().getColor(R.color.lowPriority));
                    break;
                case 1:
                    priorityColor.setBackgroundColor(getResources().getColor(R.color.mediumPriority));
                    break;
                case 2:
                    priorityColor.setBackgroundColor(getResources().getColor(R.color.hignPriority));
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
