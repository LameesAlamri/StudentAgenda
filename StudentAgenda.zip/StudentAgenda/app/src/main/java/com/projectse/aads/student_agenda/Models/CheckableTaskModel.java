package com.projectse.aads.student_agenda.Models;

public class CheckableTaskModel{
    private Boolean isChecked = false;
    private TaskModel task;

    public void setChecked(Boolean checked) {
        isChecked = checked;
    }

    public Boolean getChecked() {
        return isChecked;
    }

    public TaskModel getTask() {
        return task;
    }

    public CheckableTaskModel(TaskModel task){
        this.task = task;
    }

    public void check() {
        if (isChecked)
            isChecked = false;
        else
            isChecked = true;
    }
}