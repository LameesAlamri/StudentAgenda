package com.projectse.aads.student_agenda.Interfaces;

/**
 * Created by Davlatbek Isroilov on 4/4/2016.
 * Innopolis University
 */
public interface EditTaskCaller {
    void callEditTask();
}
