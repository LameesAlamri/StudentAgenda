# TaskTracker

Project Overview

This is a mobile application designed specifically for Innopolis university students. 
The typical user of the application is a student enrolled to several 
courses who needs to plan and distribute his or her effort across these courses. 
The goal of the application is to help students with their study related activities 
by planning (from semester plans to daily to-do lists), task decomposition, reminders, 
and visualization of their progress course-by-course. The main stakeholders are university 
students, university faculty staff, and MSIT-SE program’s faculty members.
